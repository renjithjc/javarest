package com.myproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ReadDatabase {
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/test";  
	static final String USER = "sa"; 
	static final String PASS = ""; 
	   
	public ArrayList getData(){
		
		 Connection conn = null; 
	      Statement stmt = null; 
	      ArrayList<User> userList = new ArrayList<User>();
	      try { 
	         
	         Class.forName(JDBC_DRIVER); 
	         conn = DriverManager.getConnection(DB_URL,USER,PASS);  
	         stmt = conn.createStatement(); 
	         String sql =  "select * from mytable";  
	         ResultSet rst;
	         rst = stmt.executeQuery(sql);
	         while (rst.next()) {
	             User usr = new User();
	             usr.setId(Integer.parseInt(rst.getString("id")));
	             usr.setName(rst.getString("name"));
	             usr.setEmail(rst.getString("email"));
	             userList.add(usr);
	         }
	         stmt.close(); 
	         conn.close(); 
	         
	      } catch(SQLException se) { 
	         //Handle errors for JDBC 
	         
	      } catch(Exception e) { 
	         //Handle errors for Class.forName 
	         
	      } finally { 
	         //finally block used to close resources 
	         try{ 
	            if(stmt!=null) stmt.close(); 
	         } catch(SQLException se2) { 
	         } // nothing we can do 
	         try { 
	            if(conn!=null) conn.close(); 
	         } catch(SQLException se){ 
	           
	         } //end finally try 
	      }
	      return userList;
   } 
}
