package com.myproj;

import java.util.List;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("/userdetails")
public class MyService {

	@GET
	@Path("/get")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getUserDetails() {
		ReadDatabase rdb = new ReadDatabase();
		List<User> userList = rdb.getData();
		return userList;
	}
}
 